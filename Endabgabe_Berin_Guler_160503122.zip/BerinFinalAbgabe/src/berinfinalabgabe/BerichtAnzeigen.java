/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package berinfinalabgabe;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

/**
 *
 * @author lenovo
 */
public class BerichtAnzeigen extends javax.swing.JFrame {

    private void tablo () {
   MitarbeiterPanel e = new MitarbeiterPanel();
   
    textField207.setText( e.getPas());
    
    }
    
    
    private void Berichtensonupdate () throws SQLException {
    
        DBconnecting obj_DBConnection_LMC =new DBconnecting();
	Connection baglanti =obj_DBConnection_LMC.getConnection();
        
        try {
            PreparedStatement uygula = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Musteri FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Mp FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Sno FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '100'");
        
            uygula.setString(1 ,textField207.getText()); 
            uygula.setString(2 ,textField207.getText()); 
            uygula.setString(3 ,textField207.getText()); 
            
            int donut = uygula.executeUpdate();
        

PreparedStatement uygula1 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Pa FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Mk FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Rn FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '101'");
        
            uygula1.setString(1 ,textField207.getText());
            uygula1.setString(2 ,textField207.getText());
            uygula1.setString(3 ,textField207.getText());
        
        int donut1 = uygula1.executeUpdate();
        

        PreparedStatement uygula2 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Ty FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Resimno FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Rt FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '102'");
       
            uygula2.setString(1 ,textField207.getText());
            uygula2.setString(2 ,textField207.getText());
            uygula2.setString(3 ,textField207.getText());
       
        int donut2 = uygula2.executeUpdate();
        
       
       
        PreparedStatement uygula3 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Ms FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Yd FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT İen FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '103'");
       
            uygula3.setString(1 ,textField207.getText());
            uygula3.setString(2 ,textField207.getText());
            uygula3.setString(3 ,textField207.getText());
       
        int donut3 = uygula3.executeUpdate();
        
       
        PreparedStatement uygula4 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Ds FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Ma FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Teklifno FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '104' ");
       
            uygula4.setString(1 ,textField207.getText());
            uygula4.setString(2 ,textField207.getText());
            uygula4.setString(3 ,textField207.getText());
       
        int donut4 = uygula4.executeUpdate();
        
       
       
        PreparedStatement uygula6 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Kutupmes FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Muayböl FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Ys FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '106' ");
       
            uygula6.setString(1 ,textField207.getText());
            uygula6.setString(2 ,textField207.getText());
            uygula6.setString(3 ,textField207.getText());
       
        int donut6 = uygula6.executeUpdate();
        
       
        PreparedStatement uygula7 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Cihaz FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT 'At' FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Mba FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '107'  ");
       
            uygula7.setString(1 ,textField207.getText());
            uygula7.setString(2 ,textField207.getText());
            uygula7.setString(3 ,textField207.getText());
       
        int donut7 = uygula7.executeUpdate();
        
       
        PreparedStatement uygula8 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Mpto FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Ys FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Yuzey FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '108'  ");
       
            uygula8.setString(1 ,textField207.getText());
            uygula8.setString(2 ,textField207.getText());
            uygula8.setString(3 ,textField207.getText());
       
        int donut8 = uygula8.executeUpdate();
        
       
        PreparedStatement uygula9 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Mıktek FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Muayort FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Icihtan FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '109'  ");
       
            uygula9.setString(1 ,textField207.getText());
            uygula9.setString(2 ,textField207.getText());
            uygula9.setString(3 ,textField207.getText());
       
        int donut9 = uygula9.executeUpdate();
        
       
        PreparedStatement uygula10 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Uvis FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Mgid FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Kttn FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '110'  ");
       
            uygula10.setString(1 ,textField207.getText());
            uygula10.setString(2 ,textField207.getText());
            uygula10.setString(3 ,textField207.getText());
       
        int donut10 = uygula10.executeUpdate();
        
       
        PreparedStatement uygula11 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Imes FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Isis FROM berinabgabe.berichten WHERE Rn = ? )   WHERE ID = '111'  ");
       
            uygula11.setString(1 ,textField207.getText());
            uygula11.setString(2 ,textField207.getText());
           
       
        int donut11 = uygula11.executeUpdate();
       
       
        PreparedStatement uygula17 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Stnsap FROM berinabgabe.berichten WHERE Rn = ? )   WHERE ID = '117'  ");
       
            uygula17.setString(1 ,textField207.getText());
           
        int donut17 = uygula17.executeUpdate();
        
       
        PreparedStatement uygula18 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Muaytar FROM berinabgabe.berichten WHERE Rn = ? )   WHERE ID = '118'  ");
       
            uygula18.setString(1 ,textField207.getText());
           
       
        int donut18 = uygula18.executeUpdate();
        
       
        PreparedStatement uygula19 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Acıkek FROM berinabgabe.berichten WHERE Rn = ? )   WHERE ID = '119'  ");
       
            uygula19.setString(1 ,textField207.getText());
           
       
        int donut19 = uygula19.executeUpdate();
        
       
     
       
        PreparedStatement uygula22 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET GÖZE = (SELECT Sırno1 FROM berinabgabe.berichten WHERE Rn = ? ) , TİM = (SELECT Kayparno1 FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Kontuz1 FROM berinabgabe.berichten WHERE Rn = ? ), YENE = (SELECT Kayyon1 FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Kalınlık1 FROM berinabgabe.berichten WHERE Rn = ? ) , EĞİT=(SELECT Cap1 FROM berinabgabe.berichten WHERE Rn=?), İM=(SELECT Hattip1 FROM berinabgabe.berichten WHERE Rn=?), HİZMET=(SELECT Hatyer1 FROM berinabgabe.berichten WHERE Rn=?), LERİ=(SELECT Sonuc1 FROM berinabgabe.berichten WHERE Rn=?) WHERE ID = '122' ");
       
            uygula22.setString(1 ,textField207.getText());
            uygula22.setString(2 ,textField207.getText());
            uygula22.setString(3 ,textField207.getText());
            uygula22.setString(4 ,textField207.getText());
            uygula22.setString(5 ,textField207.getText());
            uygula22.setString(6 ,textField207.getText());
            uygula22.setString(7 ,textField207.getText());
            uygula22.setString(8 ,textField207.getText());
            uygula22.setString(9 ,textField207.getText());
       
        int donut22 = uygula22.executeUpdate();
        
       
        PreparedStatement uygula23 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET GÖZE = (SELECT Sırno2 FROM berinabgabe.berichten WHERE Rn = ? ) , TİM = (SELECT Kayparno2 FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Kontuz2 FROM berinabgabe.berichten WHERE Rn = ? ), YENE = (SELECT Kayyon2 FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Kalınlık2 FROM berinabgabe.berichten WHERE Rn = ? ) , EĞİT=(SELECT Cap2 FROM berinabgabe.berichten WHERE Rn=?), İM=(SELECT Hattip2 FROM berinabgabe.berichten WHERE Rn=?), HİZMET=(SELECT Hatyer2 FROM berinabgabe.berichten WHERE Rn=?), LERİ=(SELECT Sonuc2 FROM berinabgabe.berichten WHERE Rn=?) WHERE ID = '123' ");
       
            uygula23.setString(1 ,textField207.getText());
            uygula23.setString(2 ,textField207.getText());
            uygula23.setString(3 ,textField207.getText());
            uygula23.setString(4 ,textField207.getText());
            uygula23.setString(5 ,textField207.getText());
            uygula23.setString(6 ,textField207.getText());
            uygula23.setString(7 ,textField207.getText());
            uygula23.setString(8 ,textField207.getText());
            uygula23.setString(9 ,textField207.getText());
       
       
        int donut23 = uygula23.executeUpdate();
        
       
        PreparedStatement uygula24 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET GÖZE = (SELECT Sırno3 FROM berinabgabe.berichten WHERE Rn = ? ) , TİM = (SELECT Kayparno3 FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Kontuz3 FROM berinabgabe.berichten WHERE Rn = ? ), YENE = (SELECT Kayyon3 FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Kalınlık3 FROM berinabgabe.berichten WHERE Rn = ? ) , EĞİT=(SELECT Cap3 FROM berinabgabe.berichten WHERE Rn=?), İM=(SELECT Hattip3 FROM berinabgabe.berichten WHERE Rn=?), HİZMET=(SELECT Hatyer3 FROM berinabgabe.berichten WHERE Rn=?), LERİ=(SELECT Sonuc3 FROM berinabgabe.berichten WHERE Rn=?) WHERE ID = '124' ");
       
            uygula24.setString(1 ,textField207.getText());
            uygula24.setString(2 ,textField207.getText());
            uygula24.setString(3 ,textField207.getText());
            uygula24.setString(4 ,textField207.getText());
            uygula24.setString(5 ,textField207.getText());
            uygula24.setString(6 ,textField207.getText());
            uygula24.setString(7 ,textField207.getText());
            uygula24.setString(8 ,textField207.getText());
            uygula24.setString(9 ,textField207.getText());
       
        int donut24 = uygula24.executeUpdate();
       
       
        PreparedStatement uygula25 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET GÖZE = (SELECT Sırno4 FROM berinabgabe.berichten WHERE Rn = ? ) , TİM = (SELECT Kayparno4 FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Kontuz4 FROM berinabgabe.berichten WHERE Rn = ? ), YENE = (SELECT Kayyon4 FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Kalınlık4 FROM berinabgabe.berichten WHERE Rn = ? ) , EĞİT=(SELECT Cap4 FROM berinabgabe.berichten WHERE Rn=?), İM=(SELECT Hattip4 FROM berinabgabe.berichten WHERE Rn=?), HİZMET=(SELECT Hatyer4 FROM berinabgabe.berichten WHERE Rn=?), LERİ=(SELECT Sonuc4 FROM berinabgabe.berichten WHERE Rn=?) WHERE ID = '125' ");
       
            uygula25.setString(1 ,textField207.getText());
            uygula25.setString(2 ,textField207.getText());
            uygula25.setString(3 ,textField207.getText());
            uygula25.setString(4 ,textField207.getText());
            uygula25.setString(5 ,textField207.getText());
            uygula25.setString(6 ,textField207.getText());
            uygula25.setString(7 ,textField207.getText());
            uygula25.setString(8 ,textField207.getText());
            uygula25.setString(9 ,textField207.getText());
       
       
        int donut25 = uygula25.executeUpdate();
        
       
        PreparedStatement uygula26 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET GÖZE = (SELECT Sırno5 FROM berinabgabe.berichten WHERE Rn = ? ) , TİM = (SELECT Kayparno5 FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Kontuz5 FROM berinabgabe.berichten WHERE Rn = ? ), YENE = (SELECT Kayyon5 FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Kalınlık5 FROM berinabgabe.berichten WHERE Rn = ? ) , EĞİT=(SELECT Cap5 FROM berinabgabe.berichten WHERE Rn=?), İM=(SELECT Hattip5 FROM berinabgabe.berichten WHERE Rn=?), HİZMET=(SELECT Hatyer5 FROM berinabgabe.berichten WHERE Rn=?), LERİ=(SELECT Sonuc5 FROM berinabgabe.berichten WHERE Rn=?) WHERE ID = '126' ");
       
            uygula26.setString(1 ,textField207.getText());
            uygula26.setString(2 ,textField207.getText());
            uygula26.setString(3 ,textField207.getText());
            uygula26.setString(4 ,textField207.getText());
            uygula26.setString(5 ,textField207.getText());
            uygula26.setString(6 ,textField207.getText());
            uygula26.setString(7 ,textField207.getText());
            uygula26.setString(8 ,textField207.getText());
            uygula26.setString(9 ,textField207.getText());
       
       
        int donut26 = uygula26.executeUpdate();
       
       
        PreparedStatement uygula27 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET GÖZE = (SELECT Sırno6 FROM berinabgabe.berichten WHERE Rn = ? ) , TİM = (SELECT Kayparno6 FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Kontuz6 FROM berinabgabe.berichten WHERE Rn = ? ), YENE = (SELECT Kayyon6 FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Kalınlık6 FROM berinabgabe.berichten WHERE Rn = ? ) , EĞİT=(SELECT Cap6 FROM berinabgabe.berichten WHERE Rn=?), İM=(SELECT Hattip6 FROM berinabgabe.berichten WHERE Rn=?), HİZMET=(SELECT Hatyer6 FROM berinabgabe.berichten WHERE Rn=?), LERİ=(SELECT Sonuc6 FROM berinabgabe.berichten WHERE Rn=?) WHERE ID = '127' ");
       
            uygula27.setString(1 ,textField207.getText());
            uygula27.setString(2 ,textField207.getText());
            uygula27.setString(3 ,textField207.getText());
            uygula27.setString(4 ,textField207.getText());
            uygula27.setString(5 ,textField207.getText());
            uygula27.setString(6 ,textField207.getText());
            uygula27.setString(7 ,textField207.getText());
            uygula27.setString(8 ,textField207.getText());
            uygula27.setString(9 ,textField207.getText());
       
       
        int donut27 = uygula27.executeUpdate();
        
       
        PreparedStatement uygula28 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET GÖZE = (SELECT Sırno7 FROM berinabgabe.berichten WHERE Rn = ? ) , TİM = (SELECT Kayparno7 FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Kontuz7 FROM berinabgabe.berichten WHERE Rn = ? ), YENE = (SELECT Kayyon7 FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Kalınlık7 FROM berinabgabe.berichten WHERE Rn = ? ) , EĞİT=(SELECT Cap7 FROM berinabgabe.berichten WHERE Rn=?), İM=(SELECT Hattip7 FROM berinabgabe.berichten WHERE Rn=?), HİZMET=(SELECT Hatyer7 FROM berinabgabe.berichten WHERE Rn=?), LERİ=(SELECT Sonuc7 FROM berinabgabe.berichten WHERE Rn=?) WHERE ID = '128' ");
       
            uygula28.setString(1 ,textField207.getText());
            uygula28.setString(2 ,textField207.getText());
            uygula28.setString(3 ,textField207.getText());
            uygula28.setString(4 ,textField207.getText());
            uygula28.setString(5 ,textField207.getText());
            uygula28.setString(6 ,textField207.getText());
            uygula28.setString(7 ,textField207.getText());
            uygula28.setString(8 ,textField207.getText());
            uygula28.setString(9 ,textField207.getText());
           
        int donut28 = uygula28.executeUpdate();
       
       
        PreparedStatement uygula30 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Operadsoyad FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Degeradsoyad FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Onayadsoyad FROM berinabgabe.berichten WHERE Rn = ? ), İM = (SELECT Mustadsoyad FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '130' ");
       
            uygula30.setString(1 ,textField207.getText());
            uygula30.setString(2 ,textField207.getText());
            uygula30.setString(3 ,textField207.getText());
            uygula30.setString(4 ,textField207.getText());
       
        int donut30 = uygula30.executeUpdate();
        
       
        PreparedStatement uygula31 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Operseviye FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Degerseviye FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Onayseviye FROM berinabgabe.berichten WHERE Rn = ? ), İM = (SELECT Mustseviye FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '131' ");
       
            uygula31.setString(1 ,textField207.getText());
            uygula31.setString(2 ,textField207.getText());
            uygula31.setString(3 ,textField207.getText());
            uygula31.setString(4 ,textField207.getText());
       
        int donut31 = uygula31.executeUpdate();
       
       
        PreparedStatement uygula32 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Opertarih FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Degertarih FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Onaytarih FROM berinabgabe.berichten WHERE Rn = ? ), İM = (SELECT Musttarih FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '132' ");
       
            uygula32.setString(1 ,textField207.getText());
            uygula32.setString(2 ,textField207.getText());
            uygula32.setString(3 ,textField207.getText());
            uygula32.setString(4 ,textField207.getText());
       
        int donut32 = uygula32.executeUpdate();
       
       
        PreparedStatement uygula33 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Operimza FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Degerimza FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Onayimza FROM berinabgabe.berichten WHERE Rn = ? ), İM = (SELECT Mustimza FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '133' ");
       
            uygula33.setString(1 ,textField207.getText());
            uygula33.setString(2 ,textField207.getText());
            uygula33.setString(3 ,textField207.getText());
            uygula33.setString(4 ,textField207.getText());
       
        
        } catch (Exception e) {
            
            JOptionPane.showMessageDialog(null, "Insert hatasi: "+e.getMessage()) ;
            
        }
baglanti.close() ;

    }
    
     private Connection baglantiolustur = null;
     
    public Statement ConnectStart() throws Exception {
        Class.forName("com.mysql.jdbc.Driver").newInstance(); 
        baglantiolustur = DriverManager.getConnection("jdbc:mysql://localhost:3306/berinabgabe?useSSL=false", "root", "123456");
        return baglantiolustur.createStatement();
    }
    
    public void TabloDoldur() {
try {
  
Statement st = ConnectStart(); 
ResultSet res = st.executeQuery("SELECT GÖZE, TİM, MUA, YENE, VE , EĞİT, İM, HİZMET, LERİ FROM berinabgabe.berichtenson"); //VT'den kayıtları ResultSet'e al  
   
     myTableModel model = new myTableModel(res); 
     jTable1.setModel(model); 
      baglantiolustur.close();
 
} catch (Exception e) {
    JOptionPane.showConfirmDialog(null, "Bağlantı Başarısız", "MySQL Bağlantısı", JOptionPane.PLAIN_MESSAGE);
}
}

    public void pdf () throws FileNotFoundException, IOException, DocumentException {
    
     FileInputStream input_document = new FileInputStream(new File("C:\\Users\\lenovo\\Desktop\\Test\\Muayene_gozlem_raporu.xls"));
                
                HSSFWorkbook my_xls_workbook = new HSSFWorkbook(input_document); 
               
                HSSFSheet my_worksheet = my_xls_workbook.getSheetAt(0); 
              
                Iterator<Row> rowIterator = my_worksheet.iterator();
               
                Document iText_xls_2_pdf = new Document();
                PdfWriter.getInstance(iText_xls_2_pdf, new FileOutputStream("C:\\Users\\lenovo\\Desktop\\Test\\Muayene_Gozlem_Raporu.pdf"));
                iText_xls_2_pdf.open();
                
                PdfPTable my_table = new PdfPTable(9);
                
                PdfPCell table_cell;
                
                
               
                while(rowIterator.hasNext()) {
                        Row row = rowIterator.next(); 
                        Iterator<Cell> cellIterator = row.cellIterator();
                                while(cellIterator.hasNext()) {
                                   
                                    
                                        Cell cell = cellIterator.next(); 
                                        
                                                 table_cell=new PdfPCell(new Phrase(cell.getStringCellValue()));
                                                 
                                                 my_table.addCell(table_cell);
                                                
                                        
                                        
                                }
                
                }
                
                iText_xls_2_pdf.add(my_table);                       
                iText_xls_2_pdf.close();                
                
                input_document.close(); 
                System.out.println("Basarili");
        }
    public void Excellexport () {
        	WritableWorkbook calismaalani;
            try {
           	calismaalani = Workbook.createWorkbook(new File("C:\\Users\\lenovo\\Desktop\\Test\\Muayene_gozlem_raporu.xls"));
          			
	DBconnecting obj_DBConnection_LMC =new DBconnecting();
	Connection baglanti =obj_DBConnection_LMC.getConnection();
                                
                                PreparedStatement ps=null;
				
				ResultSet rs=null;
				 
			 
	 			String query="SELECT GÖZE, TİM, MUA, YENE, VE , EĞİT, İM, HİZMET, LERİ FROM berinabgabe.berichtenson ";
			
		 			 
				
				ps=baglanti.prepareStatement(query);
				System.out.println(ps);
				rs=ps.executeQuery();
				 WritableSheet wsheet = calismaalani.createSheet("First Sheet", 0);
				 Label label = new Label(0, 2, "A label record");
				  wsheet.addCell(label);
		          int i=0;
				 
		           
		           int j=1;
				while(rs.next()){
					
					i=0;
					
					 
					 label = new Label(i++, j, rs.getString("GÖZE"));
					  wsheet.addCell(label);
					  label = new Label(i++, j, rs.getString("TİM"));
					  wsheet.addCell(label);
					  label = new Label(i++, j, rs.getString("MUA"));
					  wsheet.addCell(label); 
                                          label = new Label(i++, j, rs.getString("YENE"));
					  wsheet.addCell(label);
                                          label = new Label(i++, j, rs.getString("VE"));
					  wsheet.addCell(label);
                                          label = new Label(i++, j, rs.getString("EĞİT"));
					  wsheet.addCell(label);
                                          label = new Label(i++, j, rs.getString("İM"));
					  wsheet.addCell(label);
                                          label = new Label(i++, j, rs.getString("HİZMET"));
					  wsheet.addCell(label);
                                          label = new Label(i++, j, rs.getString("LERİ"));
					  wsheet.addCell(label);
					  
					  
					  
					 
					j++;
				}
				
				
				
            
            calismaalani.write();
            calismaalani.close();
            System.out.println("Basarili");
            
            
            
            
            
            } catch (Exception e) {
            System.out.println(e);
			}
            
        }
    
    public BerichtAnzeigen() throws SQLException {
        initComponents();
        tablo();
        Berichtensonupdate() ;
        TabloDoldur() ;
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPasswordField1 = new javax.swing.JPasswordField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        textField1 = new java.awt.TextField();
        textField207 = new java.awt.TextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        jPasswordField1.setText("jPasswordField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        textField1.setText("Rapor No");
        textField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField1ActionPerformed(evt);
            }
        });

        jButton1.setText("Zurück");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Excell Exportieren");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Pdf Als Excell Exportieren");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(43, 43, 43)
                                .addComponent(textField1, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(27, 27, 27)
                                .addComponent(textField207, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(668, 668, 668)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(282, 282, 282))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(textField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField207, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap(64, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void textField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
           
MitarbeiterPanel gui = new MitarbeiterPanel();
        gui.setVisible(true);
        setVisible(false);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try {
            pdf();
//pdf excell    // TODO add your handling code here:
        } catch (IOException ex) {
            Logger.getLogger(BerichtAnzeigen.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DocumentException ex) {
            Logger.getLogger(BerichtAnzeigen.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       Excellexport();
// TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BerichtAnzeigen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BerichtAnzeigen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BerichtAnzeigen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BerichtAnzeigen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new BerichtAnzeigen().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(BerichtAnzeigen.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private java.awt.TextField textField1;
    private java.awt.TextField textField207;
    // End of variables declaration//GEN-END:variables
}
