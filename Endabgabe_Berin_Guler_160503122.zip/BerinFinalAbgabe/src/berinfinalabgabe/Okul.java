/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package berinfinalabgabe;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author lenovo
 */
@Entity
@Table(name = "okul")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Okul.findAll", query = "SELECT o FROM Okul o")
    , @NamedQuery(name = "Okul.findByIdokul", query = "SELECT o FROM Okul o WHERE o.idokul = :idokul")
    , @NamedQuery(name = "Okul.findByAd", query = "SELECT o FROM Okul o WHERE o.ad = :ad")
    , @NamedQuery(name = "Okul.findBySoyad", query = "SELECT o FROM Okul o WHERE o.soyad = :soyad")
    , @NamedQuery(name = "Okul.findByOgrencino", query = "SELECT o FROM Okul o WHERE o.ogrencino = :ogrencino")})
public class Okul implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idokul")
    private Integer idokul;
    @Column(name = "ad")
    private String ad;
    @Column(name = "soyad")
    private String soyad;
    @Column(name = "ogrencino")
    private String ogrencino;

    public Okul() {
    }

    public Okul(Integer idokul) {
        this.idokul = idokul;
    }

    public Integer getIdokul() {
        return idokul;
    }

    public void setIdokul(Integer idokul) {
        this.idokul = idokul;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getSoyad() {
        return soyad;
    }

    public void setSoyad(String soyad) {
        this.soyad = soyad;
    }

    public String getOgrencino() {
        return ogrencino;
    }

    public void setOgrencino(String ogrencino) {
        this.ogrencino = ogrencino;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idokul != null ? idokul.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Okul)) {
            return false;
        }
        Okul other = (Okul) object;
        if ((this.idokul == null && other.idokul != null) || (this.idokul != null && !this.idokul.equals(other.idokul))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "berinfinalabgabe.Okul[ idokul=" + idokul + " ]";
    }
    
}
