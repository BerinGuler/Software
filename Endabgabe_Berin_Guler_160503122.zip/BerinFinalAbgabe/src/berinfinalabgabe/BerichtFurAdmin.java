/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package berinfinalabgabe;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.io.File;
import java.sql.ResultSet;
import jxl.Workbook; 
import jxl.write.*;

/**
 *
 * @author lenovo
 */
public class BerichtFurAdmin extends javax.swing.JFrame {

    /**
     * Creates new form BerichtFurAdmin
     */
    public BerichtFurAdmin() {
        initComponents();
    }

    
    private void Manyetikekle () {
    
        
        DBconnecting obj_DBConnection_LMC =new DBconnecting();
	Connection baglanti =obj_DBConnection_LMC.getConnection();
        
        
        try {
            PreparedStatement uygula = baglanti.prepareStatement("INSERT INTO berichten (Musteri , Mp , Sno , Pa , Mk , Rn , Ty , Resimno , Rt , Ms , Yd , İen , Ds , Ma , Teklifno , "
                    + "Kutupmes , Muayböl , Ys , Cihaz , At , Mba , Mpto , Lıs , Yuzey , Mıktek , Muayort , Icihtan , Uvıs , Mgid , Kttn , Imes , Isis , Stnsap , Muaytar , Acıkek , "
                    + " Sırno1 , Kayparno1 , Kontuz1 , Kayyon1 , Kalınlık1 , Cap1 , Hattip1 , Hatyer1 , Sonuc1 ,  Sırno2 , Kayparno2 , Kontuz2 , Kayyon2 , Kalınlık2 , Cap2 , Hattip2 , Hatyer2 , Sonuc2 , Sırno3 , Kayparno3 , Kontuz3 , Kayyon3 , Kalınlık3 , Cap3 , Hattip3 , Hatyer3 , Sonuc3 , Sırno4 , Kayparno4 , Kontuz4 , Kayyon4 , Kalınlık4 , Cap4 , Hattip4 , Hatyer4 , Sonuc4 , Sırno5 , Kayparno5 , Kontuz5 , Kayyon5 , Kalınlık5 , Cap5 , Hattip5 , Hatyer5 , Sonuc5 , Sırno6 , Kayparno6 , Kontuz6 , Kayyon6 , Kalınlık6 , Cap6 , Hattip6 , Hatyer6 , Sonuc6, Sırno7 , Kayparno7 , Kontuz7 , Kayyon7 , Kalınlık7 , Cap7 , Hattip7 , Hatyer7 , Sonuc7 , "
                    + "Operadsoyad , Degeradsoyad , Onayadsoyad , Mustadsoyad , Operseviye , Degerseviye , Onayseviye , Mustseviye , Opertarih , Degertarih , Onaytarih , Musttarih , Operimza , Degerimza , Onayimza , Mustimza  ) "
                    + "values ( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?  )  ");
        
        
        uygula.setString(1 ,jTextField1.getText());
        uygula.setString(2 ,textField203.getText());
        uygula.setString(3 ,textField206.getText());
        uygula.setString(4 ,textField204.getText());
        uygula.setString(5 ,textField205.getText());
        uygula.setString(6 ,textField207.getText());
        uygula.setString(7 ,textField208.getText());
        uygula.setString(8 ,textField211.getText());
        uygula.setString(9 ,jTextField2.getText());
        uygula.setString(10 ,textField209.getText());
        uygula.setString(11 ,jTextField3.getText());
        uygula.setString(12 ,textField211.getText());
        uygula.setString(13 ,textField210.getText());
        uygula.setString(14 ,jTextField4.getText());
        uygula.setString(15 ,jTextField5.getText());
        
        uygula.setString(16 ,textField213.getText());
        uygula.setString(17 ,textField219.getText());
        uygula.setString(18 ,textField224.getText());
        uygula.setString(19 ,textField214.getText());
        uygula.setString(20 ,textField304.getText());
        uygula.setString(21 ,textField225.getText());
        uygula.setString(22 ,textField215.getText());
        uygula.setString(23 ,textField220.getText());
        uygula.setString(24 ,textField226.getText());
        uygula.setString(25 ,textField216.getText());
        uygula.setString(26 ,textField221.getText());
        uygula.setString(27 ,textField227.getText());
        uygula.setString(28 ,textField217.getText());
        uygula.setString(29 ,textField222.getText());
        uygula.setString(30 ,textField228.getText());
        uygula.setString(31 ,textField218.getText());
        uygula.setString(32 ,textField223.getText());
        uygula.setString(33 ,textField229.getText());
        uygula.setString(34 ,textField230.getText());
        uygula.setString(35 ,textField231.getText());
        
        uygula.setString(36 ,textField232.getText());
        uygula.setString(37 ,textField239.getText());
        uygula.setString(38 ,textField246.getText());
        uygula.setString(39 ,textField253.getText());
        uygula.setString(40 ,textField260.getText());
        uygula.setString(41 ,textField267.getText());
        uygula.setString(42 ,textField274.getText());
        uygula.setString(43 ,textField281.getText());
        uygula.setString(44 ,textField1.getText());
        uygula.setString(45 ,textField233.getText());
        uygula.setString(46 ,textField240.getText());
        uygula.setString(47 ,textField247.getText());
        uygula.setString(48 ,textField254.getText());
        uygula.setString(49 ,textField261.getText());
        uygula.setString(50 ,textField268.getText());
        uygula.setString(51 ,textField275.getText());
        uygula.setString(52 ,textField282.getText());
        uygula.setString(53 ,textField2.getText());
        uygula.setString(54 ,textField234.getText());
        uygula.setString(55 ,textField241.getText());
        uygula.setString(56 ,textField248.getText());
        uygula.setString(57 ,textField255.getText());
        uygula.setString(58 ,textField262.getText());
        uygula.setString(59 ,textField269.getText());
        uygula.setString(60 ,textField276.getText());
        uygula.setString(61 ,textField283.getText());
        uygula.setString(62 ,textField3.getText());
        uygula.setString(63 ,textField235.getText());
        uygula.setString(64 ,textField242.getText());
        uygula.setString(65 ,textField249.getText());
        uygula.setString(66 ,textField256.getText());
        uygula.setString(67 ,textField263.getText());
        uygula.setString(68 ,textField270.getText());
        uygula.setString(69 ,textField277.getText());
        uygula.setString(70 ,textField284.getText());
        uygula.setString(71 ,textField4.getText());
        uygula.setString(72 ,textField236.getText());
        uygula.setString(73 ,textField243.getText());
        uygula.setString(74 ,textField250.getText());
        uygula.setString(75 ,textField257.getText());
        uygula.setString(76 ,textField264.getText());
        uygula.setString(77 ,textField271.getText());
        uygula.setString(78 ,textField278.getText());
        uygula.setString(79 ,textField285.getText());
        uygula.setString(80 ,textField5.getText());
        uygula.setString(81 ,textField237.getText());
        uygula.setString(82 ,textField244.getText());
        uygula.setString(83 ,textField251.getText());
        uygula.setString(84 ,textField258.getText());
        uygula.setString(85 ,textField265.getText());
        uygula.setString(86 ,textField272.getText());
        uygula.setString(87 ,textField279.getText());
        uygula.setString(88 ,textField286.getText());
        uygula.setString(89 ,textField6.getText());
        uygula.setString(90 ,textField238.getText());
        uygula.setString(91 ,textField245.getText());
        uygula.setString(92 ,textField252.getText());
        uygula.setString(93 ,textField259.getText());
        uygula.setString(94 ,textField266.getText());
        uygula.setString(95 ,textField273.getText());
        uygula.setString(96 ,textField280.getText());
        uygula.setString(97 ,textField287.getText());
        uygula.setString(98 ,textField7.getText());
        
        uygula.setString(99 ,textField288.getText());
        uygula.setString(100 ,textField292.getText());
        uygula.setString(101 ,textField296.getText());
        uygula.setString(102 ,textField300.getText());
        uygula.setString(103 ,textField289.getText());
        uygula.setString(104 ,textField293.getText());
        uygula.setString(105 ,textField297.getText());
        uygula.setString(106 ,textField301.getText());
        uygula.setString(107 ,textField290.getText());
        uygula.setString(108 ,textField294.getText());
        uygula.setString(109 ,textField298.getText());
        uygula.setString(110 ,textField302.getText());
        uygula.setString(111 ,textField291.getText());
        uygula.setString(112 ,textField295.getText());
        uygula.setString(113 ,textField299.getText());
        uygula.setString(114 ,textField303.getText());
        
        
        
        
        int donut = uygula.executeUpdate();
        if (donut>0) JOptionPane.showMessageDialog(null, "Basarili ") ;
        else JOptionPane.showMessageDialog(null, "Basarisiz ") ;
            
        } catch (Exception e) {
            
            JOptionPane.showMessageDialog(null, "Insert hatasi: "+e.getMessage()) ;
            
        }
        
        
        
        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    
    private void Berichtensonupdate () {
    
        DBconnecting obj_DBConnection_LMC =new DBconnecting();
	Connection baglanti =obj_DBConnection_LMC.getConnection();
        
        try {
            PreparedStatement uygula = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Musteri FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Mp FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Sno FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '100'");
        
            uygula.setString(1 ,textField207.getText()); 
            uygula.setString(2 ,textField207.getText()); 
            uygula.setString(3 ,textField207.getText()); 
            
            int donut = uygula.executeUpdate();
        

PreparedStatement uygula1 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Pa FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Mk FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Rn FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '101'");
        
            uygula1.setString(1 ,textField207.getText());
            uygula1.setString(2 ,textField207.getText());
            uygula1.setString(3 ,textField207.getText());
        
        int donut1 = uygula1.executeUpdate();
        

        PreparedStatement uygula2 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Ty FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Resimno FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Rt FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '102'");
       
            uygula2.setString(1 ,textField207.getText());
            uygula2.setString(2 ,textField207.getText());
            uygula2.setString(3 ,textField207.getText());
       
        int donut2 = uygula2.executeUpdate();
        
       
       
        PreparedStatement uygula3 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Ms FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Yd FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT İen FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '103'");
       
            uygula3.setString(1 ,textField207.getText());
            uygula3.setString(2 ,textField207.getText());
            uygula3.setString(3 ,textField207.getText());
       
        int donut3 = uygula3.executeUpdate();
        
       
        PreparedStatement uygula4 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Ds FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Ma FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Teklifno FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '104' ");
       
            uygula4.setString(1 ,textField207.getText());
            uygula4.setString(2 ,textField207.getText());
            uygula4.setString(3 ,textField207.getText());
       
        int donut4 = uygula4.executeUpdate();
        
       
       
        PreparedStatement uygula6 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Kutupmes FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Muayböl FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Ys FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '106' ");
       
            uygula6.setString(1 ,textField207.getText());
            uygula6.setString(2 ,textField207.getText());
            uygula6.setString(3 ,textField207.getText());
       
        int donut6 = uygula6.executeUpdate();
        
       
        PreparedStatement uygula7 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Cihaz FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT 'At' FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Mba FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '107'  ");
       
            uygula7.setString(1 ,textField207.getText());
            uygula7.setString(2 ,textField207.getText());
            uygula7.setString(3 ,textField207.getText());
       
        int donut7 = uygula7.executeUpdate();
        
       
        PreparedStatement uygula8 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Mpto FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Ys FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Yuzey FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '108'  ");
       
            uygula8.setString(1 ,textField207.getText());
            uygula8.setString(2 ,textField207.getText());
            uygula8.setString(3 ,textField207.getText());
       
        int donut8 = uygula8.executeUpdate();
        
       
        PreparedStatement uygula9 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Mıktek FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Muayort FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Icihtan FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '109'  ");
       
            uygula9.setString(1 ,textField207.getText());
            uygula9.setString(2 ,textField207.getText());
            uygula9.setString(3 ,textField207.getText());
       
        int donut9 = uygula9.executeUpdate();
        
       
        PreparedStatement uygula10 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Uvis FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Mgid FROM berinabgabe.berichten WHERE Rn = ? ) , HİZMET = (SELECT Kttn FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '110'  ");
       
            uygula10.setString(1 ,textField207.getText());
            uygula10.setString(2 ,textField207.getText());
            uygula10.setString(3 ,textField207.getText());
       
        int donut10 = uygula10.executeUpdate();
        
       
        PreparedStatement uygula11 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Imes FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Isis FROM berinabgabe.berichten WHERE Rn = ? )   WHERE ID = '111'  ");
       
            uygula11.setString(1 ,textField207.getText());
            uygula11.setString(2 ,textField207.getText());
           
       
        int donut11 = uygula11.executeUpdate();
       
       
        PreparedStatement uygula17 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Stnsap FROM berinabgabe.berichten WHERE Rn = ? )   WHERE ID = '117'  ");
       
            uygula17.setString(1 ,textField207.getText());
           
        int donut17 = uygula17.executeUpdate();
        
       
        PreparedStatement uygula18 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Muaytar FROM berinabgabe.berichten WHERE Rn = ? )   WHERE ID = '118'  ");
       
            uygula18.setString(1 ,textField207.getText());
           
       
        int donut18 = uygula18.executeUpdate();
        
       
        PreparedStatement uygula19 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Acıkek FROM berinabgabe.berichten WHERE Rn = ? )   WHERE ID = '119'  ");
       
            uygula19.setString(1 ,textField207.getText());
           
       
        int donut19 = uygula19.executeUpdate();
        
       
     
       
        PreparedStatement uygula22 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET GÖZE = (SELECT Sırno1 FROM berinabgabe.berichten WHERE Rn = ? ) , TİM = (SELECT Kayparno1 FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Kontuz1 FROM berinabgabe.berichten WHERE Rn = ? ), YENE = (SELECT Kayyon1 FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Kalınlık1 FROM berinabgabe.berichten WHERE Rn = ? ) , EĞİT=(SELECT Cap1 FROM berinabgabe.berichten WHERE Rn=?), İM=(SELECT Hattip1 FROM berinabgabe.berichten WHERE Rn=?), HİZMET=(SELECT Hatyer1 FROM berinabgabe.berichten WHERE Rn=?), LERİ=(SELECT Sonuc1 FROM berinabgabe.berichten WHERE Rn=?) WHERE ID = '122' ");
       
            uygula22.setString(1 ,textField207.getText());
            uygula22.setString(2 ,textField207.getText());
            uygula22.setString(3 ,textField207.getText());
            uygula22.setString(4 ,textField207.getText());
            uygula22.setString(5 ,textField207.getText());
            uygula22.setString(6 ,textField207.getText());
            uygula22.setString(7 ,textField207.getText());
            uygula22.setString(8 ,textField207.getText());
            uygula22.setString(9 ,textField207.getText());
       
        int donut22 = uygula22.executeUpdate();
        
       
        PreparedStatement uygula23 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET GÖZE = (SELECT Sırno2 FROM berinabgabe.berichten WHERE Rn = ? ) , TİM = (SELECT Kayparno2 FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Kontuz2 FROM berinabgabe.berichten WHERE Rn = ? ), YENE = (SELECT Kayyon2 FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Kalınlık2 FROM berinabgabe.berichten WHERE Rn = ? ) , EĞİT=(SELECT Cap2 FROM berinabgabe.berichten WHERE Rn=?), İM=(SELECT Hattip2 FROM berinabgabe.berichten WHERE Rn=?), HİZMET=(SELECT Hatyer2 FROM berinabgabe.berichten WHERE Rn=?), LERİ=(SELECT Sonuc2 FROM berinabgabe.berichten WHERE Rn=?) WHERE ID = '123' ");
       
            uygula23.setString(1 ,textField207.getText());
            uygula23.setString(2 ,textField207.getText());
            uygula23.setString(3 ,textField207.getText());
            uygula23.setString(4 ,textField207.getText());
            uygula23.setString(5 ,textField207.getText());
            uygula23.setString(6 ,textField207.getText());
            uygula23.setString(7 ,textField207.getText());
            uygula23.setString(8 ,textField207.getText());
            uygula23.setString(9 ,textField207.getText());
       
       
        int donut23 = uygula23.executeUpdate();
        
       
        PreparedStatement uygula24 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET GÖZE = (SELECT Sırno3 FROM berinabgabe.berichten WHERE Rn = ? ) , TİM = (SELECT Kayparno3 FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Kontuz3 FROM berinabgabe.berichten WHERE Rn = ? ), YENE = (SELECT Kayyon3 FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Kalınlık3 FROM berinabgabe.berichten WHERE Rn = ? ) , EĞİT=(SELECT Cap3 FROM berinabgabe.berichten WHERE Rn=?), İM=(SELECT Hattip3 FROM berinabgabe.berichten WHERE Rn=?), HİZMET=(SELECT Hatyer3 FROM berinabgabe.berichten WHERE Rn=?), LERİ=(SELECT Sonuc3 FROM berinabgabe.berichten WHERE Rn=?) WHERE ID = '124' ");
       
            uygula24.setString(1 ,textField207.getText());
            uygula24.setString(2 ,textField207.getText());
            uygula24.setString(3 ,textField207.getText());
            uygula24.setString(4 ,textField207.getText());
            uygula24.setString(5 ,textField207.getText());
            uygula24.setString(6 ,textField207.getText());
            uygula24.setString(7 ,textField207.getText());
            uygula24.setString(8 ,textField207.getText());
            uygula24.setString(9 ,textField207.getText());
       
        int donut24 = uygula24.executeUpdate();
       
       
        PreparedStatement uygula25 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET GÖZE = (SELECT Sırno4 FROM berinabgabe.berichten WHERE Rn = ? ) , TİM = (SELECT Kayparno4 FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Kontuz4 FROM berinabgabe.berichten WHERE Rn = ? ), YENE = (SELECT Kayyon4 FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Kalınlık4 FROM berinabgabe.berichten WHERE Rn = ? ) , EĞİT=(SELECT Cap4 FROM berinabgabe.berichten WHERE Rn=?), İM=(SELECT Hattip4 FROM berinabgabe.berichten WHERE Rn=?), HİZMET=(SELECT Hatyer4 FROM berinabgabe.berichten WHERE Rn=?), LERİ=(SELECT Sonuc4 FROM berinabgabe.berichten WHERE Rn=?) WHERE ID = '125' ");
       
            uygula25.setString(1 ,textField207.getText());
            uygula25.setString(2 ,textField207.getText());
            uygula25.setString(3 ,textField207.getText());
            uygula25.setString(4 ,textField207.getText());
            uygula25.setString(5 ,textField207.getText());
            uygula25.setString(6 ,textField207.getText());
            uygula25.setString(7 ,textField207.getText());
            uygula25.setString(8 ,textField207.getText());
            uygula25.setString(9 ,textField207.getText());
       
       
        int donut25 = uygula25.executeUpdate();
        
       
        PreparedStatement uygula26 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET GÖZE = (SELECT Sırno5 FROM berinabgabe.berichten WHERE Rn = ? ) , TİM = (SELECT Kayparno5 FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Kontuz5 FROM berinabgabe.berichten WHERE Rn = ? ), YENE = (SELECT Kayyon5 FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Kalınlık5 FROM berinabgabe.berichten WHERE Rn = ? ) , EĞİT=(SELECT Cap5 FROM berinabgabe.berichten WHERE Rn=?), İM=(SELECT Hattip5 FROM berinabgabe.berichten WHERE Rn=?), HİZMET=(SELECT Hatyer5 FROM berinabgabe.berichten WHERE Rn=?), LERİ=(SELECT Sonuc5 FROM berinabgabe.berichten WHERE Rn=?) WHERE ID = '126' ");
       
            uygula26.setString(1 ,textField207.getText());
            uygula26.setString(2 ,textField207.getText());
            uygula26.setString(3 ,textField207.getText());
            uygula26.setString(4 ,textField207.getText());
            uygula26.setString(5 ,textField207.getText());
            uygula26.setString(6 ,textField207.getText());
            uygula26.setString(7 ,textField207.getText());
            uygula26.setString(8 ,textField207.getText());
            uygula26.setString(9 ,textField207.getText());
       
       
        int donut26 = uygula26.executeUpdate();
       
       
        PreparedStatement uygula27 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET GÖZE = (SELECT Sırno6 FROM berinabgabe.berichten WHERE Rn = ? ) , TİM = (SELECT Kayparno6 FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Kontuz6 FROM berinabgabe.berichten WHERE Rn = ? ), YENE = (SELECT Kayyon6 FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Kalınlık6 FROM berinabgabe.berichten WHERE Rn = ? ) , EĞİT=(SELECT Cap6 FROM berinabgabe.berichten WHERE Rn=?), İM=(SELECT Hattip6 FROM berinabgabe.berichten WHERE Rn=?), HİZMET=(SELECT Hatyer6 FROM berinabgabe.berichten WHERE Rn=?), LERİ=(SELECT Sonuc6 FROM berinabgabe.berichten WHERE Rn=?) WHERE ID = '127' ");
       
            uygula27.setString(1 ,textField207.getText());
            uygula27.setString(2 ,textField207.getText());
            uygula27.setString(3 ,textField207.getText());
            uygula27.setString(4 ,textField207.getText());
            uygula27.setString(5 ,textField207.getText());
            uygula27.setString(6 ,textField207.getText());
            uygula27.setString(7 ,textField207.getText());
            uygula27.setString(8 ,textField207.getText());
            uygula27.setString(9 ,textField207.getText());
       
       
        int donut27 = uygula27.executeUpdate();
        
       
        PreparedStatement uygula28 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET GÖZE = (SELECT Sırno7 FROM berinabgabe.berichten WHERE Rn = ? ) , TİM = (SELECT Kayparno7 FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Kontuz7 FROM berinabgabe.berichten WHERE Rn = ? ), YENE = (SELECT Kayyon7 FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Kalınlık7 FROM berinabgabe.berichten WHERE Rn = ? ) , EĞİT=(SELECT Cap7 FROM berinabgabe.berichten WHERE Rn=?), İM=(SELECT Hattip7 FROM berinabgabe.berichten WHERE Rn=?), HİZMET=(SELECT Hatyer7 FROM berinabgabe.berichten WHERE Rn=?), LERİ=(SELECT Sonuc7 FROM berinabgabe.berichten WHERE Rn=?) WHERE ID = '128' ");
       
            uygula28.setString(1 ,textField207.getText());
            uygula28.setString(2 ,textField207.getText());
            uygula28.setString(3 ,textField207.getText());
            uygula28.setString(4 ,textField207.getText());
            uygula28.setString(5 ,textField207.getText());
            uygula28.setString(6 ,textField207.getText());
            uygula28.setString(7 ,textField207.getText());
            uygula28.setString(8 ,textField207.getText());
            uygula28.setString(9 ,textField207.getText());
           
        int donut28 = uygula28.executeUpdate();
       
       
        PreparedStatement uygula30 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Operadsoyad FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Degeradsoyad FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Onayadsoyad FROM berinabgabe.berichten WHERE Rn = ? ), İM = (SELECT Mustadsoyad FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '130' ");
       
            uygula30.setString(1 ,textField207.getText());
            uygula30.setString(2 ,textField207.getText());
            uygula30.setString(3 ,textField207.getText());
            uygula30.setString(4 ,textField207.getText());
       
        int donut30 = uygula30.executeUpdate();
        
       
        PreparedStatement uygula31 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Operseviye FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Degerseviye FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Onayseviye FROM berinabgabe.berichten WHERE Rn = ? ), İM = (SELECT Mustseviye FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '131' ");
       
            uygula31.setString(1 ,textField207.getText());
            uygula31.setString(2 ,textField207.getText());
            uygula31.setString(3 ,textField207.getText());
            uygula31.setString(4 ,textField207.getText());
       
        int donut31 = uygula31.executeUpdate();
       
       
        PreparedStatement uygula32 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Opertarih FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Degertarih FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Onaytarih FROM berinabgabe.berichten WHERE Rn = ? ), İM = (SELECT Musttarih FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '132' ");
       
            uygula32.setString(1 ,textField207.getText());
            uygula32.setString(2 ,textField207.getText());
            uygula32.setString(3 ,textField207.getText());
            uygula32.setString(4 ,textField207.getText());
       
        int donut32 = uygula32.executeUpdate();
       
       
        PreparedStatement uygula33 = baglanti.prepareStatement("UPDATE berinabgabe.berichtenson SET TİM = (SELECT Operimza FROM berinabgabe.berichten WHERE Rn = ? ) , MUA = (SELECT Degerimza FROM berinabgabe.berichten WHERE Rn = ? ) , VE = (SELECT Onayimza FROM berinabgabe.berichten WHERE Rn = ? ), İM = (SELECT Mustimza FROM berinabgabe.berichten WHERE Rn = ? )  WHERE ID = '133' ");
       
            uygula33.setString(1 ,textField207.getText());
            uygula33.setString(2 ,textField207.getText());
            uygula33.setString(3 ,textField207.getText());
            uygula33.setString(4 ,textField207.getText());
       
        int donut33 = uygula33.executeUpdate();
        if (donut33>0) JOptionPane.showMessageDialog(null, "Basarili 33 ") ;
        else JOptionPane.showMessageDialog(null, "Basarisiz 33 ") ;
        
        } catch (Exception e) {
            
            JOptionPane.showMessageDialog(null, "Insert hatasi: "+e.getMessage()) ;
            
        }

    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel3 = new javax.swing.JPanel();
        label133 = new java.awt.Label();
        label134 = new java.awt.Label();
        label135 = new java.awt.Label();
        label136 = new java.awt.Label();
        textField203 = new java.awt.TextField();
        label137 = new java.awt.Label();
        textField204 = new java.awt.TextField();
        label138 = new java.awt.Label();
        textField205 = new java.awt.TextField();
        label139 = new java.awt.Label();
        textField206 = new java.awt.TextField();
        label140 = new java.awt.Label();
        textField207 = new java.awt.TextField();
        label141 = new java.awt.Label();
        label142 = new java.awt.Label();
        label143 = new java.awt.Label();
        textField208 = new java.awt.TextField();
        textField209 = new java.awt.TextField();
        textField210 = new java.awt.TextField();
        label144 = new java.awt.Label();
        label145 = new java.awt.Label();
        label146 = new java.awt.Label();
        textField211 = new java.awt.TextField();
        label147 = new java.awt.Label();
        label148 = new java.awt.Label();
        label149 = new java.awt.Label();
        textField212 = new java.awt.TextField();
        label150 = new java.awt.Label();
        label151 = new java.awt.Label();
        label152 = new java.awt.Label();
        label153 = new java.awt.Label();
        label154 = new java.awt.Label();
        label155 = new java.awt.Label();
        label156 = new java.awt.Label();
        textField213 = new java.awt.TextField();
        textField214 = new java.awt.TextField();
        textField215 = new java.awt.TextField();
        textField216 = new java.awt.TextField();
        textField217 = new java.awt.TextField();
        textField218 = new java.awt.TextField();
        label157 = new java.awt.Label();
        label158 = new java.awt.Label();
        label159 = new java.awt.Label();
        label160 = new java.awt.Label();
        label161 = new java.awt.Label();
        label162 = new java.awt.Label();
        textField219 = new java.awt.TextField();
        textField220 = new java.awt.TextField();
        textField221 = new java.awt.TextField();
        textField222 = new java.awt.TextField();
        textField223 = new java.awt.TextField();
        label163 = new java.awt.Label();
        label164 = new java.awt.Label();
        label165 = new java.awt.Label();
        label166 = new java.awt.Label();
        label167 = new java.awt.Label();
        textField224 = new java.awt.TextField();
        textField225 = new java.awt.TextField();
        textField226 = new java.awt.TextField();
        textField227 = new java.awt.TextField();
        textField228 = new java.awt.TextField();
        label168 = new java.awt.Label();
        label169 = new java.awt.Label();
        label170 = new java.awt.Label();
        label171 = new java.awt.Label();
        label172 = new java.awt.Label();
        label173 = new java.awt.Label();
        label174 = new java.awt.Label();
        label175 = new java.awt.Label();
        label176 = new java.awt.Label();
        textField229 = new java.awt.TextField();
        label177 = new java.awt.Label();
        label178 = new java.awt.Label();
        label179 = new java.awt.Label();
        textField230 = new java.awt.TextField();
        textField231 = new java.awt.TextField();
        label180 = new java.awt.Label();
        label181 = new java.awt.Label();
        label182 = new java.awt.Label();
        label183 = new java.awt.Label();
        label184 = new java.awt.Label();
        label185 = new java.awt.Label();
        label186 = new java.awt.Label();
        label187 = new java.awt.Label();
        label188 = new java.awt.Label();
        label189 = new java.awt.Label();
        textField232 = new java.awt.TextField();
        textField233 = new java.awt.TextField();
        textField234 = new java.awt.TextField();
        textField235 = new java.awt.TextField();
        textField236 = new java.awt.TextField();
        textField237 = new java.awt.TextField();
        textField238 = new java.awt.TextField();
        textField239 = new java.awt.TextField();
        textField240 = new java.awt.TextField();
        textField241 = new java.awt.TextField();
        textField242 = new java.awt.TextField();
        textField243 = new java.awt.TextField();
        textField244 = new java.awt.TextField();
        textField245 = new java.awt.TextField();
        textField246 = new java.awt.TextField();
        textField247 = new java.awt.TextField();
        textField248 = new java.awt.TextField();
        textField249 = new java.awt.TextField();
        textField250 = new java.awt.TextField();
        textField251 = new java.awt.TextField();
        textField252 = new java.awt.TextField();
        textField253 = new java.awt.TextField();
        textField254 = new java.awt.TextField();
        textField255 = new java.awt.TextField();
        textField256 = new java.awt.TextField();
        textField257 = new java.awt.TextField();
        textField258 = new java.awt.TextField();
        textField259 = new java.awt.TextField();
        textField260 = new java.awt.TextField();
        textField261 = new java.awt.TextField();
        textField262 = new java.awt.TextField();
        textField263 = new java.awt.TextField();
        textField264 = new java.awt.TextField();
        textField265 = new java.awt.TextField();
        textField266 = new java.awt.TextField();
        textField267 = new java.awt.TextField();
        textField268 = new java.awt.TextField();
        textField269 = new java.awt.TextField();
        textField270 = new java.awt.TextField();
        textField271 = new java.awt.TextField();
        textField272 = new java.awt.TextField();
        textField273 = new java.awt.TextField();
        textField274 = new java.awt.TextField();
        textField275 = new java.awt.TextField();
        textField276 = new java.awt.TextField();
        textField277 = new java.awt.TextField();
        textField278 = new java.awt.TextField();
        textField279 = new java.awt.TextField();
        textField280 = new java.awt.TextField();
        textField281 = new java.awt.TextField();
        textField282 = new java.awt.TextField();
        textField283 = new java.awt.TextField();
        textField284 = new java.awt.TextField();
        textField285 = new java.awt.TextField();
        textField286 = new java.awt.TextField();
        textField287 = new java.awt.TextField();
        label190 = new java.awt.Label();
        label191 = new java.awt.Label();
        label192 = new java.awt.Label();
        label193 = new java.awt.Label();
        label194 = new java.awt.Label();
        label195 = new java.awt.Label();
        textField288 = new java.awt.TextField();
        textField289 = new java.awt.TextField();
        textField290 = new java.awt.TextField();
        textField291 = new java.awt.TextField();
        label196 = new java.awt.Label();
        textField292 = new java.awt.TextField();
        textField293 = new java.awt.TextField();
        textField294 = new java.awt.TextField();
        textField295 = new java.awt.TextField();
        label197 = new java.awt.Label();
        textField296 = new java.awt.TextField();
        textField297 = new java.awt.TextField();
        textField298 = new java.awt.TextField();
        textField299 = new java.awt.TextField();
        label198 = new java.awt.Label();
        textField300 = new java.awt.TextField();
        textField301 = new java.awt.TextField();
        textField302 = new java.awt.TextField();
        textField303 = new java.awt.TextField();
        jButton3 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        textField304 = new java.awt.TextField();
        jTextField2 = new javax.swing.JTextField();
        textField1 = new java.awt.TextField();
        textField2 = new java.awt.TextField();
        textField3 = new java.awt.TextField();
        textField4 = new java.awt.TextField();
        textField5 = new java.awt.TextField();
        textField6 = new java.awt.TextField();
        textField7 = new java.awt.TextField();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        label133.setAlignment(java.awt.Label.CENTER);
        label133.setBackground(new java.awt.Color(255, 153, 153));
        label133.setForeground(new java.awt.Color(255, 51, 51));
        label133.setName(""); // NOI18N
        label133.setPreferredSize(new java.awt.Dimension(58, 40));
        label133.setText("GÖZETİM MUAYENE VE EĞİTİM HİZMETLERİ");

        label134.setAlignment(java.awt.Label.CENTER);
        label134.setBackground(new java.awt.Color(255, 153, 153));
        label134.setText("MANYETİK PARÇACIK MUAYENE RAPORU");

        label135.setBackground(new java.awt.Color(255, 153, 153));
        label135.setText("Müşteri");

        label136.setBackground(new java.awt.Color(255, 153, 153));
        label136.setText("Muayene Prosedürü");

        textField203.setText("P-101-004");

        label137.setBackground(new java.awt.Color(255, 153, 153));
        label137.setText("Proje Adı");

        textField204.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField204textField1ActionPerformed(evt);
            }
        });

        label138.setBackground(new java.awt.Color(255, 153, 153));
        label138.setText("Muayene Kapsamı");

        textField205.setText("%20");

        label139.setBackground(new java.awt.Color(255, 153, 153));
        label139.setText("Sayfa No");

        textField206.setText("1");

        label140.setBackground(new java.awt.Color(51, 153, 255));
        label140.setText("Rapor No");

        label141.setBackground(new java.awt.Color(255, 153, 153));
        label141.setText("Test Yeri");

        label142.setBackground(new java.awt.Color(255, 153, 153));
        label142.setText("Muayene Standardı");

        label143.setBackground(new java.awt.Color(255, 153, 153));
        label143.setText("Değerlendiren Standardı");

        textField208.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField208textField2ActionPerformed(evt);
            }
        });

        textField209.setText("TS EN ISO 17638");

        textField210.setText("TS  EN ISO 23278 Class B");

        label144.setBackground(new java.awt.Color(255, 153, 153));
        label144.setText("Resim No");

        label145.setBackground(new java.awt.Color(255, 153, 153));
        label145.setText("Yüzey Durumu");

        label146.setBackground(new java.awt.Color(255, 153, 153));
        label146.setText("Muayene Aşaması");

        textField211.setText("-");

        label147.setBackground(new java.awt.Color(255, 153, 153));
        label147.setText("Rapor Tarihi");

        label148.setBackground(new java.awt.Color(255, 153, 153));
        label148.setText("İş Emri No");

        label149.setBackground(new java.awt.Color(255, 153, 153));
        label149.setText("Teklif No");

        label150.setAlignment(java.awt.Label.CENTER);
        label150.setBackground(new java.awt.Color(255, 153, 153));
        label150.setText("EKİPMAN BİLGİLERİ");

        label151.setBackground(new java.awt.Color(255, 153, 153));
        label151.setText("Kutup Mesafesi,mm");

        label152.setBackground(new java.awt.Color(255, 153, 153));
        label152.setText("Cihaz");

        label153.setBackground(new java.awt.Color(255, 153, 153));
        label153.setText("MP Taşıyıcı Ortam");

        label154.setBackground(new java.awt.Color(255, 153, 153));
        label154.setText("Mıknatıslama Tekniği");

        label155.setBackground(new java.awt.Color(255, 153, 153));
        label155.setText("UV Işık Şiddeti");

        label156.setBackground(new java.awt.Color(255, 153, 153));
        label156.setText("Işık Mesafesi");

        textField218.setText("textField101");

        label157.setBackground(new java.awt.Color(255, 153, 153));
        label157.setText("Muayene Bölgesi");

        label158.setBackground(new java.awt.Color(255, 153, 153));
        label158.setText("Akım Tipi");

        label159.setBackground(new java.awt.Color(255, 153, 153));
        label159.setText("Luxmetre / Işık Şiddeti");

        label160.setBackground(new java.awt.Color(255, 153, 153));
        label160.setText("Muayene Ortamı");

        label161.setBackground(new java.awt.Color(255, 153, 153));
        label161.setText("Mıknatıs Giderimi");

        label162.setBackground(new java.awt.Color(255, 153, 153));
        label162.setText("Isıl İşlem");

        textField219.setText("KAYNAK + HAZ");

        textField220.setText("1200 Lux");

        label163.setBackground(new java.awt.Color(255, 153, 153));
        label163.setText("Yüzey Sıcaklığı ");

        label164.setBackground(new java.awt.Color(255, 153, 153));
        label164.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        label164.setText("Muayene Bölgesindeki \nAlan Şiddeti, kA/m");

        label165.setBackground(new java.awt.Color(255, 153, 153));
        label165.setText("Yüzey");

        label166.setBackground(new java.awt.Color(255, 153, 153));
        label166.setText("Işık Cİhazı Tanımı");

        label167.setBackground(new java.awt.Color(255, 153, 153));
        label167.setText("Kaldırma Testi Tarih / No");

        textField224.setText("15");

        textField225.setText("3.2 kA/m");

        textField226.setText("Taslanmis");
        textField226.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField226ActionPerformed(evt);
            }
        });

        textField227.setText("***");

        label168.setBackground(new java.awt.Color(255, 153, 153));
        label168.setText("Süreksizliğin Yeri");

        label169.setBackground(new java.awt.Color(255, 153, 153));
        label169.setText("BM");

        label170.setBackground(new java.awt.Color(255, 153, 153));
        label170.setText("Ana Metal");

        label171.setBackground(new java.awt.Color(255, 153, 153));
        label171.setText("HAZ");

        label172.setBackground(new java.awt.Color(255, 153, 153));
        label172.setText("Isıdan etkilenen bölge");

        label173.setBackground(new java.awt.Color(255, 153, 153));
        label173.setText("W");

        label174.setBackground(new java.awt.Color(255, 153, 153));
        label174.setText("B");

        label175.setBackground(new java.awt.Color(255, 153, 153));
        label175.setText("Kaynak");

        label176.setBackground(new java.awt.Color(255, 153, 153));
        label176.setText("Kaynak ağzı");

        textField229.setText("Standart sapma yoktur.");

        label177.setBackground(new java.awt.Color(255, 153, 153));
        label177.setText("Standart Sapmalar");

        label178.setBackground(new java.awt.Color(255, 153, 153));
        label178.setText("Muayene Tarihleri");

        label179.setBackground(new java.awt.Color(255, 153, 153));
        label179.setText("Açıklamalar ve Ekler");

        label180.setAlignment(java.awt.Label.CENTER);
        label180.setBackground(new java.awt.Color(255, 153, 153));
        label180.setText("Muayene Sonuçları");

        label181.setBackground(new java.awt.Color(255, 153, 153));
        label181.setText("Sıra No");

        label182.setBackground(new java.awt.Color(255, 153, 153));
        label182.setText("Kaynak / Parça No");

        label183.setBackground(new java.awt.Color(255, 153, 153));
        label183.setText("Kontrol Uzun.");

        label184.setBackground(new java.awt.Color(255, 153, 153));
        label184.setText("Kaynak Yön.");

        label185.setBackground(new java.awt.Color(255, 153, 153));
        label185.setText("Kalınlık(mm)");

        label186.setBackground(new java.awt.Color(255, 153, 153));
        label186.setText("Çap(mm)");

        label187.setBackground(new java.awt.Color(255, 153, 153));
        label187.setText("Hata Tipi");

        label188.setBackground(new java.awt.Color(255, 153, 153));
        label188.setText("Hatanın Yeri");

        label189.setBackground(new java.awt.Color(255, 153, 153));
        label189.setText("Sonuç");

        textField232.setText("1");

        textField233.setText("2");

        textField234.setText("3");

        textField235.setText("4");

        textField236.setText("5");

        textField237.setText("6");

        textField238.setText("7");

        textField239.setText("TURKER ATAGUL PC");
        textField239.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField239ActionPerformed(evt);
            }
        });

        textField240.setText("TURKER ATAGUL PF");

        textField241.setText("TURKER ATAGUL PD");

        textField242.setText("TURKER ATAGUL PC");

        textField243.setText("TURKER ATAGUL PF");

        textField244.setText("TURKER ATAGUL  PD");

        textField245.setText("TURKER ATAGUL H045");

        textField246.setText("300");

        textField247.setText("300");

        textField248.setText("300");

        textField249.setText("300");

        textField250.setText("300");

        textField251.setText("300");

        textField252.setText("300");

        textField253.setText("FCAW(136)");

        textField254.setText("FCAW(136)");

        textField255.setText("FCAW(136)");

        textField256.setText("SMAW(111)");

        textField257.setText("SMAW(111)");

        textField258.setText("SMAW(111)");

        textField259.setText("TIG(141)");

        textField260.setText("12");

        textField261.setText("12");

        textField262.setText("12");

        textField263.setText("12");

        textField264.setText("12");

        textField265.setText("12");

        textField266.setText("4");

        textField267.setText("-");

        textField268.setText("-");

        textField269.setText("-");

        textField270.setText("-");

        textField271.setText("-");
        textField271.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField271textField68ActionPerformed(evt);
            }
        });

        textField272.setText("-");

        textField273.setText("4\"");

        textField282.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField282textField79ActionPerformed(evt);
            }
        });

        label190.setBackground(new java.awt.Color(255, 153, 153));
        label190.setText("Personal Bilgileri");

        label191.setBackground(new java.awt.Color(255, 153, 153));
        label191.setText("Operatör");

        label192.setBackground(new java.awt.Color(255, 153, 153));
        label192.setText("Adı Soyadı");

        label193.setBackground(new java.awt.Color(255, 153, 153));
        label193.setText("Seviye");

        label194.setBackground(new java.awt.Color(255, 153, 153));
        label194.setText("Tarih");

        label195.setBackground(new java.awt.Color(255, 153, 153));
        label195.setText("İmza");

        textField288.setText("asdf");

        textField289.setText("Level 2");

        label196.setBackground(new java.awt.Color(255, 153, 153));
        label196.setText("Değerlendiren");

        textField292.setText("asdf");

        textField293.setText("Level 2");

        label197.setBackground(new java.awt.Color(255, 153, 153));
        label197.setText("Onay");

        textField296.setText("asdf");

        textField297.setText("Level 3");

        label198.setBackground(new java.awt.Color(255, 153, 153));
        label198.setText("Müşteri");

        jButton3.setText("Zurück");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3jButton1ActionPerformed(evt);
            }
        });

        textField1.setText("textField1");

        textField2.setText("textField2");

        textField3.setText("textField3");

        textField4.setText("textField4");

        textField5.setText("textField5");

        textField6.setText("textField6");

        textField7.setText("textField7");

        jButton5.setText("Hinzufügen");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label150, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(label180, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label133, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(label134, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(label141, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label142, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label137, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label143, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label135, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(42, 42, 42)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textField209, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(textField208, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(textField204, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(textField210, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jTextField1))
                                .addGap(64, 64, 64)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(label138, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                    .addComponent(label136, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                    .addComponent(label145, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label146, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label144, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(textField211, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(textField205, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(textField203, javax.swing.GroupLayout.DEFAULT_SIZE, 133, Short.MAX_VALUE)
                                    .addComponent(jTextField3, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jTextField4, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(label148, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label149, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label147, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 114, Short.MAX_VALUE)
                                    .addComponent(label139, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label140, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(textField206, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 167, Short.MAX_VALUE)
                                    .addComponent(textField207, javax.swing.GroupLayout.DEFAULT_SIZE, 167, Short.MAX_VALUE)
                                    .addComponent(textField212, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jTextField2, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jTextField5, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGap(125, 125, 125))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(label179, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label151, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label152, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label153, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label154, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label155, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label156, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label177, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(label178, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(42, 42, 42)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(textField213, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textField214, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textField215, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textField216, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textField217, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(textField218, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(82, 82, 82)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(label159, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(label160, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(label161, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(label162, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(label157, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(label158, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(31, 31, 31)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(label168, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                                            .addComponent(label174, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                            .addComponent(label176, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                                            .addComponent(label173, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                            .addComponent(label175, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                                            .addComponent(label171, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                            .addComponent(label172, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                                            .addComponent(label169, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addGap(31, 31, 31)
                                                            .addComponent(label170, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                            .addComponent(textField221, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                            .addComponent(textField222, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                            .addComponent(textField223, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                            .addComponent(textField219, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                            .addComponent(textField220, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                            .addComponent(textField304, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGap(91, 91, 91)
                                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(label163, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(label164, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(label165, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(label166, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(label167, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGap(36, 36, 36)
                                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(textField228, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(textField227, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(textField226, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(textField224, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(textField225, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                                .addGap(0, 0, Short.MAX_VALUE))))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(textField231, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField230, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField229, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 1096, Short.MAX_VALUE))
                                        .addGap(0, 0, Short.MAX_VALUE))))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(textField238, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(label181, javax.swing.GroupLayout.DEFAULT_SIZE, 56, Short.MAX_VALUE)
                                            .addComponent(textField232, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField233, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField234, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField235, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField236, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField237, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(textField245, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addGap(77, 77, 77)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(textField244, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(textField243, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(textField242, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                            .addComponent(textField241, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                            .addComponent(textField240, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                            .addComponent(textField239, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                            .addComponent(label182, javax.swing.GroupLayout.DEFAULT_SIZE, 133, Short.MAX_VALUE))
                                                        .addGap(0, 0, Short.MAX_VALUE)))))
                                        .addGap(48, 48, 48))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(label192, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(label190, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                                            .addComponent(label193, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(label194, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(label195, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(35, 35, 35)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(textField290, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField291, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(label191, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(textField288, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField289, javax.swing.GroupLayout.DEFAULT_SIZE, 183, Short.MAX_VALUE))))
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(textField252, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField251, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField250, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField249, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField248, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField247, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(textField246, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(label183, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addGap(0, 2, Short.MAX_VALUE)))
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(textField259, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addGap(60, 60, 60)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(textField258, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 73, Short.MAX_VALUE)
                                                    .addComponent(textField257, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                                    .addComponent(textField256, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                                    .addComponent(textField255, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(textField254, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(textField253, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                                        .addComponent(label184, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(0, 0, Short.MAX_VALUE))))))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(textField294, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField293, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField292, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(label196, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 142, Short.MAX_VALUE)
                                            .addComponent(textField295, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(60, 60, 60)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(textField260, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addComponent(label185, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 15, Short.MAX_VALUE))
                                            .addComponent(textField265, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField261, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField262, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField263, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField264, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField266, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(60, 60, 60))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(textField298, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField297, javax.swing.GroupLayout.DEFAULT_SIZE, 127, Short.MAX_VALUE)
                                            .addComponent(textField296, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(label197, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField299, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(7, 7, 7)))
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(textField273, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField272, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField271, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField269, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField268, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField267, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addComponent(label186, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 1, Short.MAX_VALUE))
                                            .addComponent(textField270, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(60, 60, 60)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(textField275, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField276, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField277, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField278, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField280, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField279, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addComponent(label187, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 1, Short.MAX_VALUE))
                                            .addComponent(textField274, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(60, 60, 60)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(textField282, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField283, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField284, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField285, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField287, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textField286, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addComponent(label188, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 1, Short.MAX_VALUE))
                                            .addComponent(textField281, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addGap(60, 60, 60)
                                                .addComponent(label189, javax.swing.GroupLayout.DEFAULT_SIZE, 153, Short.MAX_VALUE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(textField1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(textField2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(textField3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(textField4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(textField5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(textField6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(textField7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(textField303, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(textField302, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(textField301, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(textField300, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(label198, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 532, Short.MAX_VALUE))
                                            .addComponent(jButton3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE)))
                                .addGap(74, 74, 74)))))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(label139, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(label133, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label134, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(label135, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(label136, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(textField203, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(textField206, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 55, Short.MAX_VALUE)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(label137, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField204, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label138, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField205, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label140, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label141, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField208, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label144, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField211, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label147, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(19, 19, 19))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(textField207, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(textField209, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(textField210, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(label142, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(label145, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(label148, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(textField212, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addGap(18, 18, 18)
                                    .addComponent(label143, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(label146, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(label149, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label150, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textField213, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(label151, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(label157, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textField219, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label158, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(label152, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textField214, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textField304, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label163, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField224, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label164, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField225, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(10, 10, 10)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label153, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField215, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label159, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField220, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label165, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField226, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label154, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField216, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label160, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField221, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label166, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField227, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label155, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField217, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label161, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField222, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label167, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label156, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField218, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label162, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField223, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(textField228, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19)
                .addComponent(label168, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label169, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label170, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(label171, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label172, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label173, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label175, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label174, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label176, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label177, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField229, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label178, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField230, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label179, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField231, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addComponent(label180, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label181, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label182, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label183, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label184, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label185, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label186, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label187, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label188, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label189, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textField232, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField239, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField246, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField253, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField260, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField267, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField274, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField281, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textField233, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField240, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField247, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField254, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField261, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField268, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField275, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField282, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(textField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(textField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textField234, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField241, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField248, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField255, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField262, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField269, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField276, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField283, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textField235, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField242, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField249, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField256, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField263, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField270, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField277, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField284, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textField236, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField243, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField250, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField257, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField264, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField271, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField278, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField285, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textField237, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField244, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField251, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField258, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField265, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField272, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField279, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField286, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textField238, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField245, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField252, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField259, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField266, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField273, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField280, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField287, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label190, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label191, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label196, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label197, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label198, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label192, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField288, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField292, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField296, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField300, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label193, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField289, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField293, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField297, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField301, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label194, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField290, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField294, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField298, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField302, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label195, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField291, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField295, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField299, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField303, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(59, 59, 59)
                        .addComponent(jButton5)
                        .addGap(42, 42, 42)
                        .addComponent(jButton3))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(textField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(textField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(26, 26, 26))
        );

        jScrollPane1.setViewportView(jPanel3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 926, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3jButton1ActionPerformed
        AdminOptions gui = new AdminOptions();
        gui.setVisible(true);
        setVisible(false);      // TODO add your handling code here:
    }//GEN-LAST:event_jButton3jButton1ActionPerformed

    private void textField282textField79ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField282textField79ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField282textField79ActionPerformed

    private void textField271textField68ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField271textField68ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField271textField68ActionPerformed

    private void textField208textField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField208textField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField208textField2ActionPerformed

    private void textField204textField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField204textField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField204textField1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

  Manyetikekle(); 
//hinzufügen       // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void textField226ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField226ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField226ActionPerformed

    private void textField239ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField239ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField239ActionPerformed
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BerichtFurAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BerichtFurAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BerichtFurAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BerichtFurAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BerichtFurAdmin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private java.awt.Label label133;
    private java.awt.Label label134;
    private java.awt.Label label135;
    private java.awt.Label label136;
    private java.awt.Label label137;
    private java.awt.Label label138;
    private java.awt.Label label139;
    private java.awt.Label label140;
    private java.awt.Label label141;
    private java.awt.Label label142;
    private java.awt.Label label143;
    private java.awt.Label label144;
    private java.awt.Label label145;
    private java.awt.Label label146;
    private java.awt.Label label147;
    private java.awt.Label label148;
    private java.awt.Label label149;
    private java.awt.Label label150;
    private java.awt.Label label151;
    private java.awt.Label label152;
    private java.awt.Label label153;
    private java.awt.Label label154;
    private java.awt.Label label155;
    private java.awt.Label label156;
    private java.awt.Label label157;
    private java.awt.Label label158;
    private java.awt.Label label159;
    private java.awt.Label label160;
    private java.awt.Label label161;
    private java.awt.Label label162;
    private java.awt.Label label163;
    private java.awt.Label label164;
    private java.awt.Label label165;
    private java.awt.Label label166;
    private java.awt.Label label167;
    private java.awt.Label label168;
    private java.awt.Label label169;
    private java.awt.Label label170;
    private java.awt.Label label171;
    private java.awt.Label label172;
    private java.awt.Label label173;
    private java.awt.Label label174;
    private java.awt.Label label175;
    private java.awt.Label label176;
    private java.awt.Label label177;
    private java.awt.Label label178;
    private java.awt.Label label179;
    private java.awt.Label label180;
    private java.awt.Label label181;
    private java.awt.Label label182;
    private java.awt.Label label183;
    private java.awt.Label label184;
    private java.awt.Label label185;
    private java.awt.Label label186;
    private java.awt.Label label187;
    private java.awt.Label label188;
    private java.awt.Label label189;
    private java.awt.Label label190;
    private java.awt.Label label191;
    private java.awt.Label label192;
    private java.awt.Label label193;
    private java.awt.Label label194;
    private java.awt.Label label195;
    private java.awt.Label label196;
    private java.awt.Label label197;
    private java.awt.Label label198;
    private java.awt.TextField textField1;
    private java.awt.TextField textField2;
    private java.awt.TextField textField203;
    private java.awt.TextField textField204;
    private java.awt.TextField textField205;
    private java.awt.TextField textField206;
    private java.awt.TextField textField207;
    private java.awt.TextField textField208;
    private java.awt.TextField textField209;
    private java.awt.TextField textField210;
    private java.awt.TextField textField211;
    private java.awt.TextField textField212;
    private java.awt.TextField textField213;
    private java.awt.TextField textField214;
    private java.awt.TextField textField215;
    private java.awt.TextField textField216;
    private java.awt.TextField textField217;
    private java.awt.TextField textField218;
    private java.awt.TextField textField219;
    private java.awt.TextField textField220;
    private java.awt.TextField textField221;
    private java.awt.TextField textField222;
    private java.awt.TextField textField223;
    private java.awt.TextField textField224;
    private java.awt.TextField textField225;
    private java.awt.TextField textField226;
    private java.awt.TextField textField227;
    private java.awt.TextField textField228;
    private java.awt.TextField textField229;
    private java.awt.TextField textField230;
    private java.awt.TextField textField231;
    private java.awt.TextField textField232;
    private java.awt.TextField textField233;
    private java.awt.TextField textField234;
    private java.awt.TextField textField235;
    private java.awt.TextField textField236;
    private java.awt.TextField textField237;
    private java.awt.TextField textField238;
    private java.awt.TextField textField239;
    private java.awt.TextField textField240;
    private java.awt.TextField textField241;
    private java.awt.TextField textField242;
    private java.awt.TextField textField243;
    private java.awt.TextField textField244;
    private java.awt.TextField textField245;
    private java.awt.TextField textField246;
    private java.awt.TextField textField247;
    private java.awt.TextField textField248;
    private java.awt.TextField textField249;
    private java.awt.TextField textField250;
    private java.awt.TextField textField251;
    private java.awt.TextField textField252;
    private java.awt.TextField textField253;
    private java.awt.TextField textField254;
    private java.awt.TextField textField255;
    private java.awt.TextField textField256;
    private java.awt.TextField textField257;
    private java.awt.TextField textField258;
    private java.awt.TextField textField259;
    private java.awt.TextField textField260;
    private java.awt.TextField textField261;
    private java.awt.TextField textField262;
    private java.awt.TextField textField263;
    private java.awt.TextField textField264;
    private java.awt.TextField textField265;
    private java.awt.TextField textField266;
    private java.awt.TextField textField267;
    private java.awt.TextField textField268;
    private java.awt.TextField textField269;
    private java.awt.TextField textField270;
    private java.awt.TextField textField271;
    private java.awt.TextField textField272;
    private java.awt.TextField textField273;
    private java.awt.TextField textField274;
    private java.awt.TextField textField275;
    private java.awt.TextField textField276;
    private java.awt.TextField textField277;
    private java.awt.TextField textField278;
    private java.awt.TextField textField279;
    private java.awt.TextField textField280;
    private java.awt.TextField textField281;
    private java.awt.TextField textField282;
    private java.awt.TextField textField283;
    private java.awt.TextField textField284;
    private java.awt.TextField textField285;
    private java.awt.TextField textField286;
    private java.awt.TextField textField287;
    private java.awt.TextField textField288;
    private java.awt.TextField textField289;
    private java.awt.TextField textField290;
    private java.awt.TextField textField291;
    private java.awt.TextField textField292;
    private java.awt.TextField textField293;
    private java.awt.TextField textField294;
    private java.awt.TextField textField295;
    private java.awt.TextField textField296;
    private java.awt.TextField textField297;
    private java.awt.TextField textField298;
    private java.awt.TextField textField299;
    private java.awt.TextField textField3;
    private java.awt.TextField textField300;
    private java.awt.TextField textField301;
    private java.awt.TextField textField302;
    private java.awt.TextField textField303;
    private java.awt.TextField textField304;
    private java.awt.TextField textField4;
    private java.awt.TextField textField5;
    private java.awt.TextField textField6;
    private java.awt.TextField textField7;
    // End of variables declaration//GEN-END:variables
}
