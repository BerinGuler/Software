
package berinfinalabgabe;


import java.sql.Connection;
import java.sql.DriverManager; 
import javax.swing.JOptionPane;

/**
 *
 * @author lenovo
 */
public class DBconnecting {
    
    public Connection getConnection(){          
		                    
		System.out.println("Baglanti Olusturuluyor");                  
		try {
            
            Class.forName("com.mysql.jdbc.Driver");
            
        } 
        
        catch (Exception e) {
            
            JOptionPane.showMessageDialog(null, "Driver hatası: "+e.getMessage()) ;
            
        }
    
    Connection baglanti1=null;
    
        try {
            baglanti1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/berinabgabe?useSSL=false", "root", "123456");
            
        } catch (Exception e) {
            
            JOptionPane.showMessageDialog(null, "Database hatası: "+e.getMessage()) ;
        }
		return baglanti1;
    
    
    
}
    
}
